JAAD ERP Clock Tracker PDF route fix (individual folder; not a ZIP)

WHY YOU GOT 404
Next.js App Router only registers API handlers from a file named route.ts inside the active app tree. A file named report-route.ts is not automatically registered.

INSTALL
1. Open your actual project root.
2. If your project uses src/app, copy this folder's file to:
   src/app/api/clock-tracker/report/route.ts
3. If your project uses app at the root instead, copy the SAME route.ts file to:
   app/api/clock-tracker/report/route.ts
   Do not create both routes unless your project intentionally has both app trees; use the active tree.
4. Confirm the route is not nested under a route group or directory with a different URL path.
5. Restart the Next.js dev server after creating the route.
6. Sign in to JAAD ERP, then test the Download PDF report button. The endpoint requires an authenticated session.

IMPORTANT
This fixes the missing/misnamed route file only if the file is placed in the app tree used by the running server. The included handler imports '@/lib/supabase/server' and reads clock_entries columns including paused_at, paused_seconds and idle_seconds; those names must exist in your actual schema. I cannot verify the full running project or Supabase schema from the supplied Clock Tracker fragment alone.

Expected URL:
http://localhost:3000/api/clock-tracker/report

Expected successful response:
HTTP 200, Content-Type: application/pdf, Content-Disposition: attachment; filename="JAAD-Clock-Tracker-Report.pdf"
A direct browser visit while signed in should download the PDF, not render a Next.js 404 page.
