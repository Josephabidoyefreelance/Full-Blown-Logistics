'use client';
import { useCallback, useEffect, useRef, useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { clockIn, clockOut, setClockPaused } from './actions';
const IDLE_MS = 5 * 60 * 1000;
export default function ClockButton({ isClockedIn, activeEntryId, pausedAt }: { isClockedIn: boolean; activeEntryId: string | null; pausedAt: string | null }) {
  const router = useRouter(); const [isPending, startTransition] = useTransition();
  const [showNotes, setShowNotes] = useState(false); const [notes, setNotes] = useState(''); const [errorMessage, setErrorMessage] = useState('');
  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null); const lastActivity = useRef(Date.now()); const busy = useRef(false); const autoPaused = useRef(false);
  const runPause = useCallback((paused: boolean, idlePause = false) => {
    if (!activeEntryId || busy.current) return;
    busy.current = true; setErrorMessage('');
    // Freeze/unfreeze the visible timer immediately; persistence follows asynchronously.
    window.dispatchEvent(new CustomEvent('clock-tracker:pause-state', { detail: { paused, at: new Date().toISOString() } }));
    startTransition(async () => { try { await setClockPaused(activeEntryId, paused, idlePause); if (!paused) autoPaused.current = false; router.refresh(); }
      catch (e) { window.dispatchEvent(new CustomEvent('clock-tracker:pause-state', { detail: { paused: !paused, at: pausedAt || new Date().toISOString() } })); setErrorMessage(e instanceof Error ? e.message : 'Could not update timer state.'); }
      finally { busy.current = false; }
    });
  }, [activeEntryId, router]);
  useEffect(() => {
    if (!isClockedIn || !activeEntryId) { if (idleTimer.current) clearTimeout(idleTimer.current); return; }
    if (pausedAt && idleTimer.current) clearTimeout(idleTimer.current);
    if (!pausedAt) lastActivity.current = Date.now();
    const scheduleIdle = () => {
      if (idleTimer.current) clearTimeout(idleTimer.current);
      idleTimer.current = setTimeout(() => {
        if (Date.now() - lastActivity.current >= IDLE_MS) { autoPaused.current = true; runPause(true, true); }
        else scheduleIdle();
      }, Math.max(0, IDLE_MS - (Date.now() - lastActivity.current)));
    };
    const pauseForAway = () => {
      if (document.visibilityState === 'hidden' || !document.hasFocus()) {
        if (!autoPaused.current) { autoPaused.current = true; runPause(true, true); }
      }
    };
    const resumeFromAway = () => {
      if (document.visibilityState === 'visible' && document.hasFocus() && autoPaused.current) {
        // The server action closes the away interval and adds it to idle_seconds.
        runPause(false, true);
        lastActivity.current = Date.now();
      }
    };
    const activity = () => { lastActivity.current = Date.now(); if (document.visibilityState === 'visible' && document.hasFocus()) scheduleIdle(); };
    const events: (keyof WindowEventMap)[] = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'pointerdown'];
    events.forEach((event) => window.addEventListener(event, activity, { passive: true }));
    document.addEventListener('visibilitychange', pauseForAway);
    window.addEventListener('blur', pauseForAway);
    window.addEventListener('focus', resumeFromAway);
    if (!pausedAt) scheduleIdle();
    return () => {
      if (idleTimer.current) clearTimeout(idleTimer.current);
      events.forEach((event) => window.removeEventListener(event, activity));
      document.removeEventListener('visibilitychange', pauseForAway);
      window.removeEventListener('blur', pauseForAway);
      window.removeEventListener('focus', resumeFromAway);
    };
  }, [isClockedIn, activeEntryId, pausedAt, runPause]);
  function doClockIn() { setErrorMessage(''); startTransition(async () => { try { await clockIn(); router.refresh(); } catch (e) { setErrorMessage(e instanceof Error ? e.message : 'Could not clock in.'); } }); }
  function doClockOut() { if (!activeEntryId) return; setErrorMessage(''); startTransition(async () => { try { await clockOut(activeEntryId, notes); setShowNotes(false); setNotes(''); router.refresh(); } catch (e) { setErrorMessage(e instanceof Error ? e.message : 'Could not clock out.'); } }); }
  return <div className="flex min-w-0 flex-col items-end gap-2">
    {!isClockedIn ? <button type="button" onClick={doClockIn} disabled={isPending} className="rounded-lg bg-green-600 px-4 py-2 text-xs font-semibold text-white hover:bg-green-700 disabled:opacity-50">{isPending ? 'Clocking in…' : 'Clock In'}</button> : <div className="flex flex-wrap items-center justify-end gap-2">
      <button type="button" onClick={() => runPause(!pausedAt, false)} disabled={isPending} className={`rounded-lg border px-3 py-2 text-xs font-semibold disabled:opacity-50 ${pausedAt ? 'border-green-600 text-green-700 hover:bg-green-50 dark:text-green-400' : 'border-amber-500 text-amber-700 hover:bg-amber-50 dark:text-amber-400'}`}>{pausedAt ? 'Resume' : 'Pause'}</button>
      {!showNotes ? <button type="button" onClick={() => setShowNotes(true)} className="rounded-lg bg-red-600 px-4 py-2 text-xs font-semibold text-white hover:bg-red-700">Clock Out</button> : <>
        <input value={notes} onChange={e => setNotes(e.target.value)} placeholder="Clock-out note (optional)" aria-label="Clock-out note" className="w-48 rounded-lg border border-neutral-200 bg-white px-3 py-2 text-xs dark:border-neutral-700 dark:bg-neutral-800" />
        <button type="button" onClick={doClockOut} disabled={isPending} className="rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50">Confirm</button>
        <button type="button" onClick={() => setShowNotes(false)} className="rounded-lg border px-3 py-2 text-xs">Cancel</button>
      </>}
    </div>}
    {errorMessage && <p role="alert" className="max-w-sm text-right text-xs text-red-600">{errorMessage}</p>}
  </div>;
}
