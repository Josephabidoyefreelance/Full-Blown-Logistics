'use server';

import { revalidatePath } from 'next/cache';
import { createClient } from '@/lib/supabase/server';

export async function clockIn() {
  const supabase = await createClient();
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) throw new Error('Please sign in before clocking in.');

  const { data: profile } = await supabase
    .from('profiles').select('full_name').eq('id', user.id).maybeSingle();

  const { data: existing, error: existingError } = await supabase
    .from('clock_entries').select('id').eq('user_id', user.id)
    .is('clock_out', null).limit(1).maybeSingle();

  if (existingError) throw new Error(existingError.message);
  if (existing) throw new Error('You are already clocked in. Clock out before starting another session.');

  const { error } = await supabase.from('clock_entries').insert({
    user_id: user.id,
    user_name: profile?.full_name || user.email || 'Staff member',
    clock_in: new Date().toISOString(),
  });
  if (error) {
    console.error('clockIn failed:', error);
    throw new Error(error.message);
  }
  revalidatePath('/clock-tracker');
}

export async function clockOut(entryId: string, notes: string) {
  const supabase = await createClient();
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) throw new Error('Please sign in before clocking out.');
  if (!entryId) throw new Error('No active clock-in session was found.');

  const { data: entry, error: fetchError } = await supabase
    .from('clock_entries')
    .select('id, clock_in, clock_out, user_id')
    .eq('id', entryId).eq('user_id', user.id).maybeSingle();

  if (fetchError || !entry) {
    console.error('clockOut fetch failed:', fetchError);
    throw new Error(fetchError?.message ?? 'The active clock-in session was not found for your account.');
  }
  if (entry.clock_out) throw new Error('This session has already been clocked out. Refresh the page.');

  // duration_minutes is database-generated; only update its source columns.
  const { data: updated, error: updateError } = await supabase
    .from('clock_entries')
    .update({ clock_out: new Date().toISOString(), notes: notes.trim() || null })
    .eq('id', entryId).eq('user_id', user.id).is('clock_out', null)
    .select('id').maybeSingle();

  if (updateError) {
    console.error('clockOut update failed:', updateError);
    throw new Error(updateError.message);
  }
  if (!updated) throw new Error('The session was not closed. Refresh and try again.');
  revalidatePath('/clock-tracker');
}
