'use client';
import { useEffect, useState } from 'react';

const WORKDAY_MINUTES = 8 * 60;
const WORKWEEK_MINUTES = 40 * 60;

function formatDuration(ms: number) {
  const seconds = Math.max(0, Math.floor(ms / 1000));
  return `${String(Math.floor(seconds / 3600)).padStart(2, '0')}:${String(Math.floor((seconds % 3600) / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}

export default function LiveWorkTime({
  clockIn, clockOut = null, regularMinutesBefore = 0, regularWeekMinutesBefore = 0,
  compact = false, display = 'both', pausedAt = null, pausedSeconds = 0,
}: {
  clockIn: string; clockOut?: string | null; regularMinutesBefore?: number;
  regularWeekMinutesBefore?: number; compact?: boolean;
  display?: 'both' | 'regular' | 'weekly' | 'overtime'; pausedAt?: string | null; pausedSeconds?: number;
}) {
  const [now, setNow] = useState(() => Date.now());
  const [optimisticPausedAt, setOptimisticPausedAt] = useState<string | null>(pausedAt);
  useEffect(() => { setOptimisticPausedAt(pausedAt); }, [pausedAt]);
  useEffect(() => {
    const onPauseState = (event: Event) => {
      const detail = (event as CustomEvent<{ paused: boolean; at?: string }>).detail;
      setOptimisticPausedAt(detail.paused ? (detail.at || new Date().toISOString()) : null);
    };
    window.addEventListener('clock-tracker:pause-state', onPauseState);
    return () => window.removeEventListener('clock-tracker:pause-state', onPauseState);
  }, []);
  useEffect(() => {
    if (clockOut || optimisticPausedAt) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [clockOut, optimisticPausedAt]);

  const end = clockOut ? new Date(clockOut).getTime() : now;
  const effectivePausedAt = optimisticPausedAt;
  const pausedNowMs = effectivePausedAt ? Math.max(0, end - new Date(effectivePausedAt).getTime()) : 0;
  const elapsedMs = Math.max(0, end - new Date(clockIn).getTime() - Math.max(0, pausedSeconds) * 1000 - pausedNowMs);
  const regularRemainingMinutes = Math.min(
    Math.max(0, WORKDAY_MINUTES - Math.max(0, regularMinutesBefore)),
    Math.max(0, WORKWEEK_MINUTES - Math.max(0, regularWeekMinutesBefore)),
  );
  const regularMs = Math.min(elapsedMs, regularRemainingMinutes * 60_000);
  const overtimeMs = Math.max(0, elapsedMs - regularMs);

  if (compact) {
    if (display === 'regular') return <span className="tabular-nums">{formatDuration(regularMs)}</span>;
    if (display === 'weekly') return <span className="tabular-nums">{formatDuration(Math.min(WORKWEEK_MINUTES * 60_000, Math.max(0, regularWeekMinutesBefore) * 60_000 + elapsedMs))}</span>;
    if (display === 'overtime') return <span className={`tabular-nums ${overtimeMs > 0 ? 'font-medium text-amber-600 dark:text-amber-400' : ''}`}>{formatDuration(overtimeMs)}</span>;
  }

  const regularTodayMs = Math.min(WORKDAY_MINUTES * 60_000, Math.max(0, regularMinutesBefore) * 60_000 + regularMs);
  const regularWeekMs = Math.min(WORKWEEK_MINUTES * 60_000, Math.max(0, regularMinutesBefore) * 60_000 + regularMs);
  return <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs tabular-nums">
    <span>Regular today <strong className="font-semibold">{formatDuration(regularTodayMs)}</strong></span>
    <span>Regular this week <strong className="font-semibold">{formatDuration(regularWeekMs)}</strong></span>
    <span>Overtime <strong className={overtimeMs > 0 ? 'font-semibold text-amber-600 dark:text-amber-400' : 'font-semibold'}>{formatDuration(overtimeMs)}</strong></span>
    {effectivePausedAt && <span className="font-semibold text-amber-600 dark:text-amber-400">Timer paused</span>}
  </div>;
}
